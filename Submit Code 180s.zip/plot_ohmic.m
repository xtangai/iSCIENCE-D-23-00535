clc
clear all
clc

load RESULT

NumOfDat = length(EIS_ref);

for i = 1:NumOfDat
    f = logspace(log10(1.15),log10(11500),35);
    f = log10(f);
    
    f1 = logspace(log10(1.15),log10(11500),10000);
    f1 = log10(f1);
    
    real_ref = real(EIS_ref(:,i));
    imag_ref = imag(EIS_ref(:,i));
    real_pred = real(EIS_pred(:,i));
    imag_pred = imag(EIS_pred(:,i));
    
    g1 = Poly8(f(:),real_ref(:));
    g2 = Poly8(f(:),imag_ref(:));
    g3 = Poly8(f(:),real_pred(:));
    g4 = Poly8(f(:),imag_pred(:));
    
    [m,n] = min(abs(g2(f1)));
    ohmic_ref(i) = g1(f1(n));
    [m,n] = min(abs(g4(f1)));
    ohmic_pred(i) = g3(f1(n));
end

err = ohmic_ref - ohmic_pred;
RMSE = rms(err);
SSR = 0;
SST = 0;
for i = 1:length(ohmic_ref)
   SSR = SSR + (ohmic_pred(i)- mean(ohmic_ref))^2;
   SST = SST + (ohmic_ref(i) - mean(ohmic_ref))^2;
end
R2 = SSR/SST;

z = figure;
set(z,'units','centimeters','Position',[5,5,13.5,6]);

subplot(1,2,1)
hold on
x_range = [13.5,17];
y_range = [13.5,17];
plot(x_range,y_range,'linewidth',1,'color','k','linestyle',':');
plot(ohmic_ref,ohmic_pred,'marker','o','linestyle','none','markersize',6)
xlabel('Referenced (m\Omega)')
ylabel('Predicted (m\Omega)')
% set(gca,'XScale','log')
xlim([13.5,17])
ylim([13.5,17])
tt = text(-0.24,1,['(a)'],'units','normalized');
tt = text(0.55,0.17,['R^2 = ',num2str(R2,'%1.4f')],'units','normalized');
tt = text(0.32,0.08,['RMSE = ',num2str(RMSE,'%1.3f'),' m\Omega'],'units','normalized');
grid on
box on

subplot(1,2,2)

histogram(err,15)
xlabel('Error (m\Omega)');
ylabel('Frequency')
xlim([-1,1])
tt = text(-0.24,1,['(b)'],'units','normalized');
grid on
box on