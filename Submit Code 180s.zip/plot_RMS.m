clc
clear all
clc

load RESULT


z = figure;
set(z,'units','centimeters','Position',[5,5,17,14]);

subplot(2,2,2)
f = logspace(log10(1.15),log10(11500),35);
NumOfDat = length(EIS_ref);
hold on 
for i = 1:NumOfDat
plot(f,real(EIS_ref(:,i)),'color',[i/NumOfDat,0,0,0.5]);
plot(f,real(EIS_pred(:,i)),'marker','.','linestyle','none','markersize',8,'color',[i/NumOfDat,0,0]);
end
xlabel('Frequency (Hz)')
ylabel('Real (m\Omega)')
set(gca,'XScale','log')
xlim([1,12000])
xticks([1,10,100,1000,10000])
tt = text(-0.25,1,['(b)'],'units','normalized');
grid on
box on

subplot(2,2,3)
f = logspace(log10(1.15),log10(11500),35);
NumOfDat = length(EIS_ref);
hold on 
for i = 1:NumOfDat
plot(f,-imag(EIS_ref(:,i)),'color',[i/NumOfDat,0,0,0.5]);
plot(f,-imag(EIS_pred(:,i)),'marker','.','linestyle','none','markersize',8,'color',[i/NumOfDat,0,0]);
end
xlabel('Frequency (Hz)')
ylabel('-Imag (m\Omega)')
set(gca,'XScale','log')
xlim([1,12000])
xticks([1,10,100,1000,10000])
grid on
box on
tt = text(-0.25,1,['(c)'],'units','normalized');
legend('Ref','Predicted')

subplot(2,2,4)
histogram(RMS,15)
xlabel('RMSE of EIS (m\Omega)');
ylabel('Frequency')
tt = text(-0.25,1,['(d)'],'units','normalized');
grid on
box on

subplot(2,2,1)
load BatDat
hold on
t = (1:length(Bat(1).Test(7).Pulse(5).Curr))/10;
yyaxis right
plot(t,Bat(1).Test(7).Pulse(5).Curr,'linewidth',1);
ylabel('Current (A)')
ylim([-0.4,1.15])
yyaxis left
plot(t,Bat(1).Test(7).Pulse(5).Volt,'linewidth',1);
ylabel('Voltage (V)')
ylim([3.72,3.81])
xlim([0,180])
xticks([0:60:180])
xlabel('Time (s)');

tt = text(-0.25,1,['(a)'],'units','normalized');
grid on
box on