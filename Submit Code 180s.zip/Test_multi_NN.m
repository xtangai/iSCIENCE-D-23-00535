% clear all data

clc
clear all
clc


% load training data set
load Train_Data_Set


% We here use 95% of the data for training, and remaining 5% for testing
L = length(IN);
training_percentage = 0.95;
L_train = round(L*training_percentage);

IN_train = IN(:,1:L_train);
OT_train = OT(:,1:L_train);

% We here use 15 networks for training, and use the median value as output
N_net = 15;

% Network Initialisation
for i = 1:N_net
    net(i).dat = feedforwardnet([15]);
end

% Network training. Parallel computing is used to save training time. About
% 3 minutes is required to train the network with a 12900H processor, 32G
% RAM.
parfor i = 1:N_net
    % When training the net, use 50% data for training, and 50% data for
    % validation, use 0% data for testing.
    net(i).dat.divideParam.trainRatio = 0.5;
    net(i).dat.divideParam.valRatio = 0.5;
    net(i).dat.divideParam.testRatio = 0.0;
    % Training function: Bayesian regularization backpropagation
    net(i).dat = trainbr(net(i).dat, IN_train,OT_train);
end

% Testing the training results
for testL = (L_train+1):(L)
    
    % Generate the referenced EIS trajectories for each load profile
    RR = load(testL).EIS.real;
    RI = load(testL).EIS.imag;
    w = 2*pi*load(testL).EIS.freq;
    R_ref = complex(RR,RI);
    
    % Get the testing input
    in = IN(:,testL);
    
    % Feed the input to all trained networks and get the response
    for i = 1:N_net
        % Feed the input to net(i) and get the reponse
        ot_tmp = sim(net(i).dat,in);
        % Recover the FOM parameters from the uniformed outputs
        ot(i).dat = approxRec_par(ot_tmp);
        % Get the frequency response of the corresponding FOM, in mohm
        tmp(i).dat = Gen_FreqResp(ot(i).dat,w)*1000;
        % Store the results;
        r_tmp(:,i) = tmp(i).dat(:);
    end
    
    % calculate the median value respectively for real and imagine parts
    r_id_real = median(real(r_tmp),2);
    r_id_imag = median(imag(r_tmp),2);
    r_id = complex(r_id_real,r_id_imag);
    
    % Calculate the RMSE, and save the final results
    RMS(testL) = rms(r_id(:) - R_ref(:));
    EIS_pred(:,testL) = r_id;
    EIS_ref(:,testL) = R_ref;
end

% Remove the results corresponding to the training phase (should be zero)
EIS_pred(:,1:L_train) = [];
EIS_ref(:,1:L_train) = [];
RMS(1:L_train) = [];

% Preview
hist(RMS,20)

% Save Results
save RESULT RMS EIS_ref EIS_pred net