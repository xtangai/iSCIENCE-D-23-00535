clc
clear all
clc

load RESULT

[val,ind] = sort(RMS);

z = figure;
set(z,'units','centimeters','Position',[5,5,20,18],'PaperType','a3');

str = 'abcdefghijklmnopq';

for i = 1:8

subplot(4,4,i)
plotnum = ind(i);
ref = EIS_ref(:,plotnum);
pred = EIS_pred(:,plotnum);
hold on 
plot(real(ref),-imag(ref),'linewidth',1);
plot(real(pred),-imag(pred),'marker','o','linestyle','none','linewidth',1,'markersize',4);
xlabel('Real (m\Omega)')
ylabel('-Imag (m\Omega)')
box on
grid on
tt = text(-0.32,1,['(',str(i),')'],'units','normalized');
tt = text(0.1,0.07,['RMSE: ',num2str(RMS(plotnum),'%1.3f'),'m\Omega'],'units','normalized','Fontsize',9);
a = min(real(ref));
b = max(real(ref));
c = min(-imag(ref));
d = max(-imag(ref));

% a = floor(a/5)*4.5;
% b = ceil(b/5)*5.5;
% c = floor(c/5)*5.5;
% d = ceil(d/5)*5.5;
xlim([a-2,b+5])
ylim([c-5,d+3])

end

for i = 1:8

subplot(4,4,i+8)
plotnum = ind(end-8+i);
ref = EIS_ref(:,plotnum);
pred = EIS_pred(:,plotnum);
hold on 
plot(real(ref),-imag(ref),'linewidth',1);
plot(real(pred),-imag(pred),'marker','o','linestyle','none','linewidth',1,'markersize',4);
xlim([10,40])
ylim([-10,20])
xlabel('Real (m\Omega)')
ylabel('-Imag (m\Omega)')
box on
grid on
tt = text(-0.32,1,['(',str(i+8),')'],'units','normalized');
tt = text(0.1,0.07,['RMSE: ',num2str(RMS(plotnum),'%1.3f'),'m\Omega'],'units','normalized','Fontsize',9);
a = min(real(ref));
b = max(real(ref));
c = min(-imag(ref));
d = max(-imag(ref));

% a = floor(a/5)*4.5;
% b = ceil(b/5)*5.5;
% c = floor(c/5)*5.5;
% d = ceil(d/5)*5.5;
xlim([a-2,b+5])
ylim([c-5,d+3])

end

legend('Ref','Predicted')