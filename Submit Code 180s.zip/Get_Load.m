%% Get Load
clc
clear all
clc

load BatDat

loadnum = 0;
for i = 1:16
    for j = 1:14
        for k = 1:5
            loadnum = loadnum +1;
            load(loadnum).Curr = Bat(i).Test(j).Pulse(k).Curr(1:1:end);
            load(loadnum).Curr = [0;load(loadnum).Curr];
            load(loadnum).Volt = Bat(i).Test(j).Pulse(k).Volt(1:1:end);
            load(loadnum).Volt = [Bat(i).Test(j).Pulse(k).OCV;load(loadnum).Volt];
            load(loadnum).D = load(loadnum).Volt - load(loadnum).Volt(1);
            load(loadnum).EIS = Bat(i).Test(j).EIS;
            load(loadnum).param = Bat(i).Test(j).EIS.param;
            load(loadnum).OCV = Bat(i).Test(j).Pulse(k).OCV;
        end
    end
end
save Load load
