function [fitresult, gof] = Poly8(f, imag_pred)
%CREATEFIT(F,IMAG_PRED)
%  Create a fit.
%
%  Data for 'untitled fit 1' fit:
%      X Input : f
%      Y Output: imag_pred
%  Output:
%      fitresult : a fit object representing the fit.
%      gof : structure with goodness-of fit info.
%
%  另请参阅 FIT, CFIT, SFIT.

%  由 MATLAB 于 23-Jun-2022 19:05:26 自动生成


%% Fit: 'untitled fit 1'.
[xData, yData] = prepareCurveData( f, imag_pred );

% Set up fittype and options.
ft = fittype( 'poly8' );

% Fit model to data.
[fitresult, gof] = fit( xData, yData, ft );




