%% Gen_Load_Multiple_Time
clc
clear all
clc

load Load.mat




L = length(load);

in = [];
ot = [];
IN_s = [];
OT_s = [];

% Change the time to check the cases with different testing durations. When
% time == 1800, it means the testing duration is 180 seconds. You may be
% willing to use 'time = [300,600,1200];' to test the hybrid cases. 
time = [1800];

for fitting_length = time
    for i = 1:L
        fitting_order = 5;
        for ii = (fitting_order+1):fitting_length
            
            Y(ii-fitting_order,1) = load(i).D(ii);
            ytmp = load(i).D((ii-fitting_order):(ii-1));
            utmp = load(i).Curr((ii-fitting_order):(ii));
            ytmp = fliplr(ytmp);
            utmp = fliplr(utmp);
            ytmp = ytmp(:)';
            utmp = utmp(:)';
            H(ii-fitting_order,:) = [ytmp,utmp];
            
        end
        sigma = min(svd([H,Y]));
        c = (H'*H - sigma^2*eye(2*fitting_order+1))^(-1)*H'*Y;
        IN_s(:,i) = [c(:);load(i).Volt(1)];
        tmp = load(i).param(:);
        OT_s(:,i) = [approxUni_par(tmp)];
    end
    in = [in,IN_s];
    ot = [ot,OT_s];
end

tmp = [];
for i = 1:length(time)
    z = load;
    for j = 1:length(z)
        z(j).Curr = z(j).Curr(1:time(i));
        z(j).Volt = z(j).Volt(1:time(i));
        z(j).D = z(j).D(1:time(i));
    end
    tmp = [tmp,z];
end
loadz = tmp;

L = length(in);
index = randperm(L);

for i = 1:L
    IN(:,i) = in(:,index(i));
    OT(:,i) = ot(:,index(i));
    load(i) = loadz(index(i));
end

save Train_Data_Set IN OT load