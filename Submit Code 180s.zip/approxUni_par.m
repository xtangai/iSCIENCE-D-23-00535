function [par_01] = approxUni_par(par)
par = par(:);
min = [0.002;0.002;1.5;0.5;0.005;5;0.1;350;0.2;1e-7;0.05];
dist =[0.01;0.1;10;0.5;0.1;25;0.5;2000;1;5e-8;0.25];
par_01 = (par-min)./dist;

end

