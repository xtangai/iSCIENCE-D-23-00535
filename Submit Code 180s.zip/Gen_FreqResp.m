function [r] = Gen_FreqResp(par,w)

% par(1); Ro
% par(2); Rp
% par(3); Cp
% par(4); alpha
% par(5); Rb
% par(6); Cb
% par(7); beta
% par(8); Cs
% par(9); gamma
% par(10); L
% par(11); R

for i = 1:length(w)
    G1 = par(1);
    G2 = par(2)/(1+par(2)*par(3)*(j*w(i))^par(4));
    G3 = par(5)/(1+par(5)*par(6)*(j*w(i))^par(7));
    G4 = 1/(par(8)*(j*w(i))^par(9));
    G5 = par(10)*par(11)*(j*w(i))/(par(11)+par(10)*(j*w(i)));
    r(i) = G1+G2+G3+G4+G5;
end

% G1 = newfotf([num2str(par(1))],'1');
% G2 = newfotf([num2str(par(2))],['1+',num2str(par(2)),'*',num2str(par(3)),'*s^',num2str(par(4))]);
% G3 = newfotf([num2str(par(5))],['1+',num2str(par(5)),'*',num2str(par(6)),'*s^',num2str(par(7))]);
% G4 = newfotf('1',[num2str(par(8)),'*s^',num2str(par(9))]);
% G5 = newfotf([num2str(par(10)),'*',num2str(par(11)),'*s'],[num2str(par(11)),'+',num2str(par(10)),'*s']);
% 
% 
% 
% G = G1+G2+G3+G4+G5;

end

