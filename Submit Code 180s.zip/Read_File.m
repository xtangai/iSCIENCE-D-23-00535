% Read File
clc
clear all
clc

totalTest = 13

file_count = 0;

for tNum = [0]
    testNum = tNum + 1;
    str1 = ['Test',num2str(tNum)];
    str4 = ['-',num2str(31+tNum),'.xlsx'];
    for deviceNum = 1:2
        str2 = ['\240032-',num2str(deviceNum)];
        for channelNum = 1:8
            str3 = ['-',num2str(channelNum)];
            str = [str1,str2,str3,str4];
            file_count = file_count + 1
            a = xlsread(str,'EIS');
            b = xlsread(str,'record');
            
            if deviceNum == 1
                batNum = channelNum;
            else
                batNum = 8+channelNum;
            end
            
            Bat(batNum).Test(testNum).EIS.freq = a(:,1);
            Bat(batNum).Test(testNum).EIS.real = a(:,2);
            Bat(batNum).Test(testNum).EIS.imag = -a(:,3);
            
            ind = find(b(:,3)==3+2);
            Bat(batNum).Test(testNum).Pulse(1).OCV = b(ind(end),8);
            ind = find(b(:,3)>=4+2 & b(:,3)<=51+2);
            Bat(batNum).Test(testNum).Pulse(1).Curr = b(ind,7);
            Bat(batNum).Test(testNum).Pulse(1).Volt = b(ind,8);
            
            ind = find(b(:,3)==52+2);
            Bat(batNum).Test(testNum).Pulse(2).OCV = b(ind(end),8);
            ind = find(b(:,3)>=53+2 & b(:,3)<=76+2);
            Bat(batNum).Test(testNum).Pulse(2).Curr = b(ind,7);
            Bat(batNum).Test(testNum).Pulse(2).Volt = b(ind,8);
            
            ind = find(b(:,3)==77+2);
            Bat(batNum).Test(testNum).Pulse(3).OCV = b(ind(end),8);
            ind = find(b(:,3)>=78+2 & b(:,3)<=149+2);
            Bat(batNum).Test(testNum).Pulse(3).Curr = b(ind,7);
            Bat(batNum).Test(testNum).Pulse(3).Volt = b(ind,8);
            
            ind = find(b(:,3)==150+2);
            Bat(batNum).Test(testNum).Pulse(4).OCV = b(ind(end),8);
            ind = find(b(:,3)>=151+2 & b(:,3)<=168+2);
            Bat(batNum).Test(testNum).Pulse(4).Curr = b(ind,7);
            Bat(batNum).Test(testNum).Pulse(4).Volt = b(ind,8);
            
            ind = find(b(:,3)==169+2);
            Bat(batNum).Test(testNum).Pulse(5).OCV = b(ind(end),8);
            ind = find(b(:,3)>=170+2 & b(:,3)<=181+2);
            Bat(batNum).Test(testNum).Pulse(5).Curr = b(ind,7);
            Bat(batNum).Test(testNum).Pulse(5).Volt = b(ind,8);
            
        end
    end
end


for tNum = 1:1:(totalTest)
    testNum = tNum + 1;
    str1 = ['Test',num2str(tNum)];
    str4 = ['-',num2str(31+tNum),'.xlsx'];
    for deviceNum = 1:2
        str2 = ['\240032-',num2str(deviceNum)];
        for channelNum = 1:8
            str3 = ['-',num2str(channelNum)];
            str = [str1,str2,str3,str4];
            file_count = file_count + 1
            a = xlsread(str,'EIS');
            b = xlsread(str,'record');
            
            if deviceNum == 1
                batNum = channelNum;
            else
                batNum = 8+channelNum;
            end
            
            Bat(batNum).Test(testNum).EIS.freq = a(:,1);
            Bat(batNum).Test(testNum).EIS.real = a(:,2);
            Bat(batNum).Test(testNum).EIS.imag = -a(:,3);
            
            ind = find(b(:,3)==3);
            Bat(batNum).Test(testNum).Pulse(1).OCV = b(ind(end),8);
            ind = find(b(:,3)>=4 & b(:,3)<=51);
            Bat(batNum).Test(testNum).Pulse(1).Curr = b(ind,7);
            Bat(batNum).Test(testNum).Pulse(1).Volt = b(ind,8);
            
            ind = find(b(:,3)==52);
            Bat(batNum).Test(testNum).Pulse(2).OCV = b(ind(end),8);
            ind = find(b(:,3)>=53 & b(:,3)<=76);
            Bat(batNum).Test(testNum).Pulse(2).Curr = b(ind,7);
            Bat(batNum).Test(testNum).Pulse(2).Volt = b(ind,8);
            
            ind = find(b(:,3)==77);
            Bat(batNum).Test(testNum).Pulse(3).OCV = b(ind(end),8);
            ind = find(b(:,3)>=78 & b(:,3)<=149);
            Bat(batNum).Test(testNum).Pulse(3).Curr = b(ind,7);
            Bat(batNum).Test(testNum).Pulse(3).Volt = b(ind,8);
            
            ind = find(b(:,3)==150);
            Bat(batNum).Test(testNum).Pulse(4).OCV = b(ind(end),8);
            ind = find(b(:,3)>=151 & b(:,3)<=168);
            Bat(batNum).Test(testNum).Pulse(4).Curr = b(ind,7);
            Bat(batNum).Test(testNum).Pulse(4).Volt = b(ind,8);
            
            ind = find(b(:,3)==169);
            Bat(batNum).Test(testNum).Pulse(5).OCV = b(ind(end),8);
            ind = find(b(:,3)>=170 & b(:,3)<=181);
            Bat(batNum).Test(testNum).Pulse(5).Curr = b(ind,7);
            Bat(batNum).Test(testNum).Pulse(5).Volt = b(ind,8);
            
        end
    end
end

for i = 1:16
    for j = 1:totalTest+1
        for k = 1:5
            ii = 1;
            tmp = length(Bat(i).Test(j).Pulse(k).Curr)-1;
            while (ii<tmp)
                ii = ii + 1;
                if abs(Bat(i).Test(j).Pulse(k).Curr(ii) - Bat(i).Test(j).Pulse(k).Curr(ii-1))>0.035
                    Bat(i).Test(j).Pulse(k).Curr(ii) = [];
                    Bat(i).Test(j).Pulse(k).Volt(ii) = [];
                    tmp = length(Bat(i).Test(j).Pulse(k).Curr)-1;
                end
            end
        end
    end
end

save BatDat Bat

